# Documentation of ThesisABM

[comment]:This file is generated at the creation of the model file. Feel free to modify it in any way you want. 
---

## Author
### saracamachoamado

## Description

Based on the internal empty template.

## Elements

[See structure](Thesis%20ABM_structure.md)

